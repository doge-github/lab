# 构建前须知

**代码一经发出，原则上不负责售后**

跑前请先去TransformViewModel.kt填入自己申请的和风天气[apikey](https://dev.qweather.com/docs/api/)方可使用
