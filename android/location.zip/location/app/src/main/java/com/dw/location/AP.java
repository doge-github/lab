package com.ymc.location;

public class AP {
    public String SSID;
    public String BSSID;
    public int level;

    public AP(String SSID, String BSSID, int level) {
        this.SSID = SSID;
        this.BSSID = BSSID;
        this.level = level;
    }

}

