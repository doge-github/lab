package com.ymc.location;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView wifiList;
    TextView titleTV;
    TextView wifiStatus;
    MaterialButton button_store;
    MaterialButton button_loc;
    MaterialButton button_refresh;
    List <ScanResult> wifiResults;
    String TAG="wifiTest";
    WifiManager wm;
    List <AP> nowAps;
    List <Point> storePoints;
    TextInputEditText pointName;
    TextInputEditText X_val;
    TextInputEditText Y_val;

    final int minLevel=256;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super .onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wm=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiList=(TextView)findViewById(R.id.wifiList);
        titleTV=findViewById(R.id.titleTV);
        button_store=findViewById(R.id.button_store);
        button_store.setOnClickListener(this);
        button_loc=findViewById(R.id.button_loc);
        button_loc.setOnClickListener(this);
        button_refresh=findViewById(R.id.button_refresh);
        button_refresh.setOnClickListener(this);
        storePoints=new ArrayList<>();
        wifiStatus=findViewById(R.id.wifiStatus);

        new wifiThread().start();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            //申请WRITE_EXTERNAL_STORAGE权限
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    1);
        }

    }

    @Override
    public void onClick(View v) {
        try{
            switch (v.getId()){
                case R.id.button_store:
                    Log.i(TAG,"button_store_click");
                    showStoreDialog();
                    break;
                case R.id.button_loc:
                    Point thisPoint=new Point();
                    thisPoint.aps=nowAps;
                    StringBuffer sb=new StringBuffer();
                    sb.append("您当前的坐标为：");
                    String pointXY=getPointXY(thisPoint);
                    sb.append(pointXY);
                    titleTV.setText(sb.toString());
                    Toast.makeText(MainActivity.this,"定位成功",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.button_refresh:
                    storePoints=new ArrayList<>();
                    break;
            }
        }finally {
            wifiStatus.setText(R.string.refresh_no);
        }
    }

    private String getPointXY(Point thisPoint){
        String XY="未知位置";
        double distance=Double.MAX_VALUE;
        double thisDis=0;
        for(int i=0;i<storePoints.size();i++){
            thisDis=getDistance(thisPoint,storePoints.get(i));
            Log.i(TAG+"getDistance",storePoints.get(i).pName+thisDis);
            if(thisDis<distance){
                distance=thisDis;
                StringBuffer sb=new StringBuffer();
                sb.append(storePoints.get(i).pName+'\n');
                sb.append("坐标点为：("+storePoints.get(i).x+","+storePoints.get(i).y+")");
                Log.i(TAG+"getPointXY",storePoints.get(i).pName+" "+sb.toString());
                XY=sb.toString();
            }
        }
        Log.i(TAG+"getPointXY","========================================");
        return XY;
    }

    private double getDistance(Point p1,Point p2){
        double dis=0;
        Map<String,Integer> p1map=new HashMap<>();
        Map<String,Integer> p2map=new HashMap<>();
        for(int i=0;i<p1.aps.size();i++)
        {
            p1map.put(p1.aps.get(i).BSSID,p1.aps.get(i).level);
        }
        for(int i=0;i<p2.aps.size();i++)
        {
            p2map.put(p2.aps.get(i).BSSID,p2.aps.get(i).level);
        }
        for(int i=0;i<p1.aps.size();i++)
        {
            String p1iBSSID=p1.aps.get(i).BSSID;
            //如果p1（待测点）的ap信息在p2中存在 则计算两点的差值
            if(p2map.containsKey(p1iBSSID))
            {
                dis+=(p1map.get(p1iBSSID)-p2map.get(p1iBSSID))*
                        (p1map.get(p1iBSSID)-p2map.get(p1iBSSID));
            }
            else
            {
                dis+=(p1map.get(p1iBSSID)-minLevel)*
                        (p1map.get(p1iBSSID)-minLevel);
            }
        }

        return Math.sqrt(dis);
    }

    private void showStoreDialog(){
        View storeContent= getLayoutInflater().inflate(R.layout.dialog_store,null);
        pointName=storeContent.findViewById(R.id.text_pointName);
        X_val=storeContent.findViewById(R.id.text_X);
        Y_val=storeContent.findViewById(R.id.text_Y);
        pointName.setText("坐标"+storePoints.size()+"号");
        X_val.setText("0");
        Y_val.setText("0");
        new AlertDialog.Builder(MainActivity.this)
                .setView(storeContent)
                .setTitle(R.string.tips_enter)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try{
                            String pointNameString=pointName.getText().toString().trim();
                            String X_valString=X_val.getText().toString().trim();
                            String Y_valString=Y_val.getText().toString().trim();
                            if(!pointNameString.isEmpty()&&!X_valString.isEmpty()&&!Y_valString.isEmpty()){
                                double X_valDouble=Double.parseDouble(X_valString);
                                double Y_valDouble=Double.parseDouble(Y_valString);
                                Point thisPoint=new Point();
                                thisPoint.x=X_valDouble;
                                thisPoint.y=Y_valDouble;
                                thisPoint.pName=pointNameString;
                                thisPoint.aps=nowAps;
                                storePoints.add(thisPoint);
                                Toast.makeText(MainActivity.this,"保存成功",Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(MainActivity.this,"保存失败 请不要存在空值",Toast.LENGTH_SHORT).show();
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                            Toast.makeText(MainActivity.this,"保存失败 请在X Y处填入double类型的值",Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .show();
    }

    private class wifiThread extends Thread{
        @Override
        public void run() {
            while (true){
                try{
                    wifiResults=wm.getScanResults();
                    Log.i(TAG+"wifiThread",wifiResults.toString());
                    StringBuffer sb=new StringBuffer();
                    sb.append("共有"+wifiResults.size()+"个APs被检测到\n\n");
                    //得到现在的wifi列表
                    nowAps=new ArrayList<>();
                    for(int i=0;i<wifiResults.size();i++)
                    {
                        sb.append("SSID: "+wifiResults.get(i).SSID+"\n");
                        sb.append("BSSID "+wifiResults.get(i).BSSID+"\n");
                        sb.append("level "+wifiResults.get(i).level+"\n");
                        sb.append("\n\n");
                        Log.i(TAG+"wifiThread",sb.toString());
                        Log.i(TAG+"wifiThread","=========================");
                        //只保存信号强度-80以上的数据
                        if(wifiResults.get(i).level>-80)
                        {
                            AP ap=new AP(wifiResults.get(i).SSID,wifiResults.get(i).BSSID,wifiResults.get(i).level);
                            nowAps.add(ap);
                        }
                    }
                    sb.append("共有"+nowAps.size()+"个APs信号强度在-80以上");
                    Message msg=Message.obtain();
                    msg.obj=sb.toString();
                    msg.what=1;
                    msghandler.sendMessage(msg);
                    sleep(1000);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    private Handler msghandler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    Log.i(TAG+"Handler","handlerRunning");
                    wifiList.setText(msg.obj.toString());
                    wifiStatus.setText(R.string.refresh_yes);
                    break;
            }
        }
    };
}

