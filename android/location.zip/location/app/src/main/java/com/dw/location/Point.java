package com.ymc.location;

import java.util.ArrayList;
import java.util.List;

public class Point {
    public String pName;
    public double x;
    public double y;
    public List <AP> aps=new ArrayList<>();
}
