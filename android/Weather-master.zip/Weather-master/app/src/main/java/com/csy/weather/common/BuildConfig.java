package com.csy.weather.common;

/**
 * Created by csy on 2016/7/2.
 */
public class BuildConfig {

    public static boolean isDebug = true;
}
