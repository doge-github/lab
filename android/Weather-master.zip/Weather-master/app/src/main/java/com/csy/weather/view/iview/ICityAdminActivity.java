package com.csy.weather.view.iview;

/**
 * Created by csy on 2016/7/17.
 */
public interface ICityAdminActivity {

}
